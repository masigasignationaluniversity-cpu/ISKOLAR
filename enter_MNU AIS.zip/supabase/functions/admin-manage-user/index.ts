import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.8';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;

    // Use service role if available, fallback to anon (SECURITY DEFINER functions handle auth bypass)
    const supabaseAdmin = createClient(
      supabaseUrl,
      serviceKey || anonKey,
      { auth: { persistSession: false } }
    );

    const body = await req.json();
    const { action, caller_local_id } = body;

    console.log('admin-manage-user action:', action, 'caller:', caller_local_id, 'using key:', serviceKey ? 'service_role' : 'anon_fallback');

    // Verify the caller is an admin
    if (caller_local_id) {
      const { data: callerProfile, error: callerErr } = await supabaseAdmin
        .from('profiles')
        .select('role')
        .eq('local_id', caller_local_id)
        .eq('role', 'admin')
        .maybeSingle();

      if (callerErr) {
        console.error('Admin check DB error:', callerErr.message);
        return new Response(JSON.stringify({ error: 'Admin check failed: ' + callerErr.message }), {
          status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      if (!callerProfile) {
        console.warn('Admin check failed: no admin profile found for', caller_local_id);
        return new Response(JSON.stringify({ error: 'Forbidden - admin only' }), {
          status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    // ── CREATE ──────────────────────────────────────────────────
    if (action === 'create') {
      const { username, password, role, name, local_id, email, department, college, program, year_level, student_number, employee_id } = body;

      // Hash the password
      const { data: hashData, error: hashErr } = await supabaseAdmin.rpc('hash_password', { p_password: password });
      if (hashErr) {
        console.error('hash_password error:', hashErr.message);
        throw new Error('Password hashing failed: ' + hashErr.message);
      }

      // Use SECURITY DEFINER function to bypass RLS for the INSERT
      const { error: insertErr } = await supabaseAdmin.rpc('create_profile_admin', {
        p_id: crypto.randomUUID(),
        p_local_id: local_id,
        p_username: username,
        p_role: role,
        p_name: name,
        p_email: email || (username + '@ais.local'),
        p_contact_email: email || null,
        p_department: department || null,
        p_college: college || null,
        p_program: program || null,
        p_year_level: year_level || null,
        p_student_number: student_number || null,
        p_employee_id: employee_id || null,
        p_password_hash: hashData,
      });

      if (insertErr) {
        console.error('create_profile_admin error:', insertErr.message);
        throw new Error(insertErr.message);
      }

      console.log('User created:', local_id, 'role:', role);
      return new Response(JSON.stringify({ success: true, localId: local_id }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // ── UPDATE CREDENTIALS (upsert + always activate) ───────────
    if (action === 'update_credentials') {
      const { local_id, new_username, new_password } = body;

      const { data: existing } = await supabaseAdmin
        .from('profiles')
        .select('local_id, status')
        .eq('local_id', local_id)
        .maybeSingle();

      if (existing) {
        const dbUpdates: Record<string, unknown> = { status: 'active' };
        if (new_username) dbUpdates.username = new_username;
        if (new_password) {
          const { data: hashData, error: hashErr } = await supabaseAdmin.rpc('hash_password', { p_password: new_password });
          if (hashErr) throw new Error('Password hashing failed: ' + hashErr.message);
          dbUpdates.password_hash = hashData;
        }
        const { error } = await supabaseAdmin.from('profiles').update(dbUpdates).eq('local_id', local_id);
        if (error) throw new Error(error.message);
        console.log('Credentials updated for:', local_id);
      } else {
        console.warn('update_credentials: user not found in DB:', local_id);
        return new Response(JSON.stringify({ error: 'user_not_found', localId: local_id }), {
          status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // ── BULK SYNC — upsert all portal users into DB ─────────────
    if (action === 'bulk_sync') {
      const { users } = body as { users: Array<{
        local_id: string; username: string; password: string; role: string;
        name: string; email?: string; department?: string; college?: string; program?: string;
        year_level?: number; student_number?: string; employee_id?: string; status?: string;
      }> };

      console.log('bulk_sync: syncing', users.length, 'users');
      const results: { local_id: string; status: string }[] = [];

      for (const u of users) {
        try {
          const { data: hashData, error: hashErr } = await supabaseAdmin.rpc('hash_password', { p_password: u.password });
          if (hashErr) { results.push({ local_id: u.local_id, status: 'hash_error: ' + hashErr.message }); continue; }

          const { error: upsertErr } = await supabaseAdmin.from('profiles').upsert({
            id: crypto.randomUUID(),
            local_id: u.local_id,
            username: u.username,
            role: u.role,
            name: u.name,
            email: u.email || (u.username + '@ais.local'),
            contact_email: u.email || null,
            department: u.department || null,
            college: u.college || null,
            program: u.program || null,
            year_level: u.year_level || null,
            student_number: u.student_number || null,
            employee_id: u.employee_id || null,
            status: u.status ?? 'active',
            password_hash: hashData,
          }, { onConflict: 'local_id', ignoreDuplicates: false });

          if (upsertErr) { results.push({ local_id: u.local_id, status: 'error: ' + upsertErr.message }); }
          else { results.push({ local_id: u.local_id, status: 'ok' }); }
        } catch (e) {
          results.push({ local_id: u.local_id, status: 'exception: ' + String(e) });
        }
      }

      const failed = results.filter(r => r.status !== 'ok');
      console.log('bulk_sync done. failed:', failed.length);
      return new Response(JSON.stringify({ success: true, results, failed }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // ── DELETE — hard-delete from profiles ──────────────────────
    if (action === 'delete') {
      const { local_id } = body;
      const { error: credErr } = await supabaseAdmin.from('user_credentials').delete().eq('local_id', local_id);
      if (credErr) console.warn('user_credentials delete warn:', credErr.message);
      const { error: profileErr } = await supabaseAdmin.from('profiles').delete().eq('local_id', local_id);
      if (profileErr) throw new Error('Failed to delete profile: ' + profileErr.message);
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // ── DEACTIVATE (legacy) ──────────────────────────────────────
    if (action === 'deactivate') {
      const { local_id } = body;
      await supabaseAdmin.from('profiles').update({ status: 'inactive' }).eq('local_id', local_id);
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ error: 'Unknown action' }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (err) {
    console.error('admin-manage-user error:', err);
    const msg = err instanceof Error ? err.message : String(err);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});