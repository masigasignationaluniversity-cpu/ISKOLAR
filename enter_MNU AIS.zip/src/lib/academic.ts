import type { Grade, Section, Course, Term } from './types';
import type { GradeValue } from './types';

// ─── Year Classification ───────────────────────────────────────────────────────
export type YearClassification = 'Freshman' | 'Sophomore' | 'Junior' | 'Senior';

/**
 * Classifies a student's year level based on the percentage of total program units completed.
 * < 25%      → Freshman
 * 25–50%     → Sophomore
 * 50–75%     → Junior
 * ≥ 75%      → Senior
 */
export function getYearClassification(passedUnits: number, totalProgramUnits: number): YearClassification {
  if (totalProgramUnits <= 0) return 'Freshman';
  const pct = passedUnits / totalProgramUnits;
  if (pct < 0.25) return 'Freshman';
  if (pct < 0.50) return 'Sophomore';
  if (pct < 0.75) return 'Junior';
  return 'Senior';
}

/**
 * Returns the percentage of units completed as a number between 0 and 1.
 */
export function getCompletionPercent(passedUnits: number, totalProgramUnits: number): number {
  if (totalProgramUnits <= 0) return 0;
  return Math.min(1, passedUnits / totalProgramUnits);
}

/**
 * Counts the total academic units a student has passed (numeric grade ≤ 3.0),
 * using the effective grade (removal grade if officially submitted).
 * PE and NSTP are excluded.
 */
export function getPassedUnits(
  studentId: string,
  grades: Grade[],
  sections: Section[],
  courses: Course[],
  enrollments?: { studentId: string; sectionId: string; termId: string; status: string }[],
): number {
  return grades
    .filter(g => g.studentId === studentId && g.submitted && g.grade !== null)
    .reduce((sum, g) => {
      const sec = sections.find(s => s.id === g.sectionId);
      const course = sec ? courses.find(c => c.id === sec.courseId) : null;
      if (!course || course.isPE || course.isNSTP) return sum;
      // Skip if the corresponding enrollment was officially dropped
      if (enrollments) {
        const enr = enrollments.find(e => e.studentId === studentId && e.sectionId === g.sectionId && e.termId === g.termId);
        if (enr?.status === 'dropped') return sum;
      }
      const effective = (g.removalSubmitted && g.removalGrade) ? g.removalGrade : g.grade!;
      const numGrade = parseFloat(effective as string);
      if (isNaN(numGrade) || numGrade > 3.0) return sum; // 4, 5, INC, DRP, F don't count
      return sum + course.units + (course.labUnits ?? 0);
    }, 0);
}

// ─── Scholastic Standing ───────────────────────────────────────────────────────
export type ScholasticStanding =
  | 'Good Standing'
  | 'Warning'
  | 'Probation'
  | 'Dismissal'
  | 'Permanent Disqualification';

export interface ScholasticResult {
  standing: ScholasticStanding;
  totalAcademicUnits: number;
  failedUnits: number;
  failedPercent: number;
}

/**
 * Computes scholastic standing for a specific term.
 *
 * Rules (from university code):
 * - INC and DRP are excluded from the computation
 * - Grade of 4 counts as failing until it is removed
 * - After removal: only the final removal grade (3.0 or 5.0) is counted
 * - PE and NSTP are excluded
 *
 * Failed % thresholds:
 * - 0%–24%   → Good Standing (passes ≥ 75% of academic units)
 * - 25%–49%  → Warning
 * - 50%–75%  → Probation
 * - 76%–99%  → Dismissal
 * - 100%     → Permanent Disqualification
 */
export function getScholasticStanding(
  studentId: string,
  termId: string,
  grades: Grade[],
  sections: Section[],
  courses: Course[],
): ScholasticResult | null {
  const termGrades = grades.filter(g =>
    g.studentId === studentId &&
    g.termId === termId &&
    g.submitted &&
    g.grade !== null &&
    g.grade !== 'INC' &&  // INC excluded from computation
    g.grade !== 'DRP',    // DRP excluded from computation
  );

  if (termGrades.length === 0) return null;

  let totalAcademicUnits = 0;
  let failedUnits = 0;

  for (const g of termGrades) {
    const sec = sections.find(s => s.id === g.sectionId);
    const course = sec ? courses.find(c => c.id === sec.courseId) : null;
    if (!course || course.isPE || course.isNSTP) continue;

    const units = course.units + (course.labUnits ?? 0);
    totalAcademicUnits += units;

    // Effective grade: use removal grade if officially submitted
    const effective = (g.removalSubmitted && g.removalGrade) ? g.removalGrade : g.grade!;
    const numGrade = parseFloat(effective as string);

    // Failing = numeric grade > 3.0 (i.e., 4 or 5)
    if (!isNaN(numGrade) && numGrade > 3.0) {
      failedUnits += units;
    }
  }

  if (totalAcademicUnits === 0) return null;

  const failedPercent = failedUnits / totalAcademicUnits;

  let standing: ScholasticStanding;
  if (failedPercent >= 1.0) standing = 'Permanent Disqualification';
  else if (failedPercent >= 0.76) standing = 'Dismissal';
  else if (failedPercent >= 0.50) standing = 'Probation';
  else if (failedPercent >= 0.25) standing = 'Warning';
  else standing = 'Good Standing';

  return { standing, totalAcademicUnits, failedUnits, failedPercent };
}

// ─── Display helpers ──────────────────────────────────────────────────────────
export function scholasticStandingColor(standing: ScholasticStanding): string {
  switch (standing) {
    case 'Good Standing': return 'bg-green-100 text-green-800 border-green-300';
    case 'Warning': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    case 'Probation': return 'bg-orange-100 text-orange-800 border-orange-300';
    case 'Dismissal': return 'bg-red-100 text-red-800 border-red-300';
    case 'Permanent Disqualification': return 'bg-red-200 text-red-900 border-red-400';
  }
}

export function yearClassificationColor(yc: YearClassification): string {
  switch (yc) {
    case 'Freshman': return 'bg-blue-100 text-blue-800 border-blue-300';
    case 'Sophomore': return 'bg-purple-100 text-purple-800 border-purple-300';
    case 'Junior': return 'bg-amber-100 text-amber-800 border-amber-300';
    case 'Senior': return 'bg-green-100 text-green-800 border-green-300';
  }
}

// ─── Prescription Period (INC / 4.0) ─────────────────────────────────────────
// One (1) academic year = three (3) terms (1st Sem → 2nd Sem → Mid-Year)

const SEMESTER_ORDER: Record<string, number> = { '1st': 0, '2nd': 1, 'Mid-Term': 2 };

/**
 * Sort terms chronologically by academic year, then by semester sequence:
 * 1st Semester → 2nd Semester → Mid-Year / Summer
 */
export function sortTermsChronologically(terms: Term[]): Term[] {
  return [...terms].sort((a, b) => {
    const ayDiff = a.academicYear.localeCompare(b.academicYear);
    if (ayDiff !== 0) return ayDiff;
    return (SEMESTER_ORDER[a.semester] ?? 3) - (SEMESTER_ORDER[b.semester] ?? 3);
  });
}

/**
 * Return how many terms have passed from the grade term up to (but not including) the reference term.
 * E.g. grade in term index 2, reference index 5 → 3 terms have passed.
 */
export function termsSinceGrade(gradeTermId: string, referenceTermId: string, sortedTerms: Term[]): number {
  const gi = sortedTerms.findIndex(t => t.id === gradeTermId);
  const ri = sortedTerms.findIndex(t => t.id === referenceTermId);
  if (gi === -1 || ri === -1) return 0;
  return Math.max(0, ri - gi);
}

/**
 * Returns true when the 1-academic-year (3-term) prescription period has elapsed.
 */
export function isPrescriptionExpired(gradeTermId: string, referenceTermId: string, sortedTerms: Term[]): boolean {
  return termsSinceGrade(gradeTermId, referenceTermId, sortedTerms) >= 3;
}

/**
 * Returns the term that is exactly 3 terms after the grade term (the deadline term).
 * Returns null if data is insufficient.
 */
export function getPrescriptionDeadlineTerm(gradeTermId: string, sortedTerms: Term[]): Term | null {
  const idx = sortedTerms.findIndex(t => t.id === gradeTermId);
  if (idx === -1) return null;
  return sortedTerms[idx + 3] ?? null;
}

/**
 * Human-readable deadline label: "End of <term name>" or "Expired" if past deadline.
 */
export function getPrescriptionDeadlineLabel(gradeTermId: string, terms: Term[]): { label: string; expired: boolean; urgent: boolean } {
  const sorted = sortTermsChronologically(terms);
  const refTerm = sorted.find(t => t.isActive) ?? sorted[sorted.length - 1];
  const deadlineTerm = getPrescriptionDeadlineTerm(gradeTermId, sorted);
  if (!deadlineTerm) return { label: 'Unknown', expired: false, urgent: false };
  const expired = refTerm ? isPrescriptionExpired(gradeTermId, refTerm.id, sorted) : false;
  const termsSince = refTerm ? termsSinceGrade(gradeTermId, refTerm.id, sorted) : 0;
  return {
    label: expired ? `Expired (was: End of ${deadlineTerm.name})` : `End of ${deadlineTerm.name}`,
    expired,
    urgent: !expired && termsSince === 2, // last term before deadline
  };
}

/**
 * Returns true if a 4.0 grade should be auto-converted to 5.0.
 * Purely time-based: if 3+ terms (1 academic year) have passed since the grade
 * was given and no removal exam has been submitted, the grade auto-converts.
 * Re-enrollment in the same course is a separate academic record and does NOT
 * reset or extend the prescription period for the original 4.0.
 */
export function shouldAutoConvert40(
  grade: Grade,
  _allGrades: Grade[],
  _sections: Section[],
  sortedTerms: Term[],
  referenceTermId: string,
): boolean {
  if (grade.grade !== '4') return false;
  if (grade.removalSubmitted) return false;
  return isPrescriptionExpired(grade.termId, referenceTermId, sortedTerms);
}

/**
 * Get the effective grade applying all academic rules:
 * - Uses removalGrade if officially submitted
 * - Auto-converts 4.0 → 5.0 if prescription expired and no re-enrollment within year
 * - Otherwise returns original grade
 */
export function getEffectiveGradeWithRules(
  grade: Grade,
  allGrades: Grade[],
  sections: Section[],
  terms: Term[],
): GradeValue | null {
  if (!grade.grade || !grade.submitted) return null;
  if (grade.removalSubmitted && grade.removalGrade) return grade.removalGrade;
  const sorted = sortTermsChronologically(terms);
  const refTerm = sorted.find(t => t.isActive) ?? sorted[sorted.length - 1];
  if (refTerm && shouldAutoConvert40(grade, allGrades, sections, sorted, refTerm.id)) return '5';
  return grade.grade;
}

/**
 * Returns true if a student is restricted from re-enrolling in a course
 * because they have an active, uncompleted INC within the 3-term window.
 * Rule: "A course with an INC may not be re-enrolled within the period or term."
 */
export function isIncEnrollmentRestricted(
  studentId: string,
  courseId: string,
  grades: Grade[],
  sections: Section[],
  terms: Term[],
): boolean {
  const sorted = sortTermsChronologically(terms);
  const refTerm = sorted.find(t => t.isActive) ?? sorted[sorted.length - 1];
  if (!refTerm) return false;
  return grades.some(g => {
    if (g.studentId !== studentId || g.grade !== 'INC' || !g.submitted) return false;
    if (g.removalSubmitted) return false; // already completed
    const sec = sections.find(s => s.id === g.sectionId);
    if (!sec || sec.courseId !== courseId) return false;
    return !isPrescriptionExpired(g.termId, refTerm.id, sorted);
  });
}
